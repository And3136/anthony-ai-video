import os, uuid, subprocess, asyncio
from pathlib import Path
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field

app = FastAPI(title="Anthony AI Video API")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

OUT = Path(os.getenv("OUTPUT_DIR", "./outputs"))
OUT.mkdir(parents=True, exist_ok=True)
WAN = os.getenv("WAN_REPO", "./Wan2.1")
CKPT = os.getenv("WAN_CKPT_DIR", "./Wan2.1-T2V-1.3B")

class GenerateRequest(BaseModel):
    prompt: str = Field(min_length=3, max_length=1000)
    size: str = "832*480"
    seconds: int = Field(default=5, ge=3, le=5)

jobs = {}

@app.get("/health")
def health():
    return {"ok": True, "model": "Wan2.1-T2V-1.3B", "ready": Path(CKPT).exists()}

@app.post("/generate")
async def generate(req: GenerateRequest):
    job_id = str(uuid.uuid4())
    jobs[job_id] = {"status": "queued"}
    asyncio.create_task(run_job(job_id, req))
    return {"job_id": job_id, "status": "queued"}

@app.get("/jobs/{job_id}")
def job(job_id: str):
    if job_id not in jobs:
        raise HTTPException(404, "Job not found")
    return jobs[job_id]

async def run_job(job_id, req):
    try:
        jobs[job_id] = {"status": "generating"}
        outdir = OUT / job_id
        outdir.mkdir(parents=True, exist_ok=True)
        cmd = [
            "python", "generate.py",
            "--task", "t2v-1.3B",
            "--size", req.size,
            "--ckpt_dir", CKPT,
            "--offload_model", "True",
            "--t5_cpu",
            "--sample_shift", "8",
            "--sample_guide_scale", "6",
            "--prompt", req.prompt
        ]
        proc = await asyncio.create_subprocess_exec(*cmd, cwd=WAN,
            stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.STDOUT)
        log = []
        while True:
            line = await proc.stdout.readline()
            if not line: break
            log.append(line.decode(errors="ignore")[-500:])
            jobs[job_id]["log"] = "".join(log[-10:])
        code = await proc.wait()
        videos = list(outdir.glob("*.mp4")) + list(Path(WAN).glob("*.mp4"))
        if code != 0 or not videos:
            jobs[job_id] = {"status":"error","message":"Generation failed","log":"".join(log[-20:])}
            return
        src = videos[-1]
        dest = outdir / "video.mp4"
        if src.resolve() != dest.resolve():
            src.replace(dest)
        jobs[job_id] = {"status":"done","video":f"/videos/{job_id}/video.mp4"}
    except Exception as e:
        jobs[job_id] = {"status":"error","message":str(e)}

from fastapi.responses import FileResponse
@app.get("/videos/{job_id}/video.mp4")
def video(job_id: str):
    p = OUT / job_id / "video.mp4"
    if not p.exists(): raise HTTPException(404, "Video not ready")
    return FileResponse(p, media_type="video/mp4", filename="anthony-ai-video.mp4")
