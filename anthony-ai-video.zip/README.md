# Anthony AI Video
Real AI video generator using a Next.js-style frontend and a FastAPI backend prepared for Wan2.1 T2V-1.3B.

## Architecture
Browser -> FastAPI -> Wan2.1 -> MP4

The model should run on a GPU machine. The app is free for users; production GPU compute still needs a host.

## Backend
Install Python 3.10+, PyTorch 2.4+, then Wan2.1 requirements. Put `Wan2.1-T2V-1.3B` in the backend machine and set `WAN_CKPT_DIR`.

Run:
`uvicorn backend.main:app --host 0.0.0.0 --port 8000`

## Frontend
Serve `frontend/index.html` with any static host. Set `API_URL` in the file if backend is not on the same origin.

Wan2.1 is open source and its official repository documents T2V-1.3B at 480p and about 8.19GB VRAM.
